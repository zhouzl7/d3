# D3-Treemap Diagram

Treemap Diagram with three sets of data: KickerStarters, Movies, and Video games

## Installation

Download files [here](https://github.com/Stevegolden12/D3-TreemapDiagram)

## Acknowledgement

Thank you to freeCodeCamp for teaching me how to do this project